<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Politique de confidentialité | Macirvie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        .global{
            color:'#fff';
            margin:20px
        }
        .table1 td{
            border:1px solid #fff;
            padding:5px
        }
        .table1{
            margin-bottom:10px
        }
        h1{
            font-size:25px
        }
    </style>
</head>

<body style="color:#fff;background-color:#1e3c8a;height: 100%;align-content : center;margin-left:20;margin-right:20;font-size:14px">
<div style="display:flex;align-items:center;flex-direction:column">
<div style="margin:20px">
    <img src="{{ asset('/assets/img/logo.png')}}" style="max-width:250px">

</div>
    <div >
        <div class="global justify-content-center">
            <div class="col-md-12" style="max-width:900px">
              <h1>Protection des données personnelles des utilisateurs de notre site web</h1>
              <p>La présente politique a pour objet d’apporter des informations sur : </p>
              <ul>
                <li>Les données personnelles qui sont collectées ou traitées lorsque vous utilisez le site web de Macir Vie depuis le lien https://www.macirvie.com;</li>
                <li>La façon dont vos données personnelles sont traitées et protégées;</li>
                <li>Vos droits s’agissant des données personnelles;</li>
                <li>Les cookies;</li>
                <li>Comment nous contacter.</li>
              </ul>
              <p>Et ce en respectant la Loi n° 18-07 du 25 Ramadhan 1439 correspondant au 10 juin 2018 relative à la protection des personnes physiques dans le traitement des données à caractère personnel.</p>
              <p>À ce titre, <strong>Macir Vie</strong> s’engage à protéger vos données personnelles, que vous avez bien voulu lui confier. </p>
              <p>À cet effet, certaines données personnelles sont nécessaires afin de nous permettre de répondre à vos besoins, c’est le cas notamment lorsque :</p>
              <ul>
                <li>Vous utilisez notre site ou souscrivez à un de nos produits;</li>
                <li>Vous avez créé votre espace client;</li>
                <li>Vous avez accédé à la rubrique Contactez-nous.</li>
              </ul>
              <h6>Ces données sont:</h6>
              <ul>
                <li>Nom;</li>
                <li>Prénom;</li>
                <li>Numéro de téléphone;</li>
                <li>Fonction;</li>
                <li>Adresse email;</li>
                <li>Objet;</li>
                <li>Numéro de passeport;</li>
                <li>Destination;</li>

              </ul>
              <p>Lorsqu’il y a interaction avec notre site web, certaines données sont automatiquement collectées depuis votre navigateur Internet. Les cookies sont des petits fichiers texte insérés dans votre navigateur pendant que vous naviguez sur le web à la demande du serveur gérant le site Web visité. Il contient des informations sur la navigation effectuée sur les pages de ce site, leur utilisation est destinée à améliorer la performance du site et à vous proposer des offres, contenus et services adaptés à vos besoins et à vos centres d’intérêt. </p>
              <h6>Que fait Macir Vie avec vos données personnelles :</h6>
              <p>À l’envoi de vos demandes de devis ou pour les besoins de la gestion de votre contrat d’assurance, Macir Vie exploite les données informatiques à caractère personnel vous concernant. Celle-ci nous permettent de :</p>
              <ul>

        
              <li>Répondre à votre demande de devis ou contrat en utilisant les informations insérées (nom, prénom, numéro de téléphone, email…);
              <li>De vous transmettre les informations suite à votre abonnement à nos newsletters;
              <li>Vous contacter en cas de non concrétisation de contrat (arrêt sur l’étape devis);
              <li>Gérer vos contrats souscrits en ligne :</li>
              <ul >
                <li>D’honorer votre souscription à nos contrats;</li>
                <li>Exécuter le contrat et de gérer votre dossier (Sinistres, remboursements, étude de dossier);</li>
                <li>Gérer la relation client:</li>
                <li>Remplir les obligations légales;</li>
                <li>De vérifier l’exactitude de vos informations;</li>
                <li>Vous informer des dates d’échéances de vos contrats via divers canaux (e-mail, SMS ; téléphone),</li>
                <li>Lutter contre la fraude.</li>

                </ul>
               <li>Réaliser nos études statistiques, marketing et audit;</li>
               <li>Vous proposer des enquêtes de satisfaction afin d’améliorer nos services.</li>
              </ul>
              <p><strong>Macir Vie </strong>s’engage à ce que vos données ne soient pas exploitées autres que ce qui est mentionné ci-dessus. </p>
                <h6>Comment notre site est protégé ? </h6>
              <p>Lors de l’accès au site https://www.macirvie.com, vous constaterez qu’il est totalement sécurisé dès la page d’accueil, par la présence d’un certificat de sécurité SSL pour plus d’informations cliquez sur le symbole :</p>
             <img src="{{ asset('/storage/images/cadenas.png')}}" style="width:30px;margin-bottom:20px;margin-left:10px"/>
              <h6>Mesure de protection</h6>
                <p>En plus de la sensibilisation des collaborateurs qui suivent régulièrement des formations dans ce sens.</p>
                <p>Nous déployons des mesures de sécurité physiques, logiques et organisationnelles afin d’améliorer la protection et ce dans le but de garantir la confidentialité, l’intégrité, la disponibilité des informations et la traçabilité des accès. Ces mesures respectent les normes internationales et les règles de l’état de l’art.</p>
                <p>Dans le cadre de leurs activités, nos collaborateurs sont engagés à respecter nos chartes internes, politiques de sécurité, de confidentialité et de protection des données personnelles.</p>
             <h6>Qui est destinataire de vos données, </h6>
            <p>Dans le cadre de notre relation, vos données sont traitées par nos départements centraux et sont transmises à nos réassureurs et assisteurs en cas de sinistre dans le cadre de l’assurance voyage et éventuellement à notre régulateur.</p>
            <p>Leur transfert se fait de manière stricte et sécurisée.</p>
            <p>Le partage de vos informations à un tiers en dehors de Macirvie SPA ne sera effectué que si le tiers a accepté de garder vos informations personnelles strictement confidentielles et de les utiliser uniquement aux fins spécifiques pour lesquelles nous leur fournissons et cela dans le cadre d’une relation contractuelle.</p>
            <h6>Durée de conservation de vos données</h6>
<p>Les durées de conservation varient selon notre relation contractuelle.</p>
<ul>
<li>Client Actif : Contrat d’assurance en cours;</li>
<li>Client inactif : Contrat d’assurance expiré;</li>
<li>Prospect : Vous vous êtes arrêté au stade du devis sans souscrire à un contrat.</li>
</ul>

<p>Les données collectées que vous avez autorisées ont une durée de conservation spécifique.</p>
<table class="table1" style="border:1px solid #fff">
<tbody>
<tr style="background:grey">
<td>Type de client</td>
<td>Durée de conservation</td>
</tr>
<tr>
<td>Actif</td>
<td>Pendant toute la durée de la relation contractuelle</td>
</tr>
<tr>
<td>Inactif</td>
<td>10 ans</td>
</tr>
<tr>
<td>Prospect</td>
<td>3 ans</td>
</tr>
</tbody>
</table>
<p>En tout état de cause, nous révisons régulièrement les informations que nous détenons. Lorsque leur conservation n’est plus justifiée par des exigences légales, commerciales ou liées à la gestion de votre compte client, ou si vous avez fait usage d’un droit de modification ou d’effacement, nous les supprimerons de façon sécurisée.</p>

<h6>Vos droits d’accès</h6>
<p>En respect de la réglementation, toute personne à le droit d’accès, de rectification et d’opposition. Ainsi vous pouvez nous contacter par email à l’adresse courrier@macirvie.com et demander la rectification, ou la suppression de vos données personnelles, </p>
<p>À noter que les données d’un contrat en vigueur ne peuvent être supprimées. </p>

<h6>Les Cookies</h6>
<p>Un cookie est un fichier texte déposé lors de la consultation d’un site, d’une application mobile ou d’une publicité en ligne et stocké dans un espace spécifique du disque dur de votre ordinateur ou de votre appareil mobile. Les cookies sont gérés par votre navigateur Internet ou l’application mobile que vous utilisez, et seul l’émetteur d’un cookie peut décider de la lecture ou de la modification des informations qui y sont contenues.</p>
 
<p>Un cookie ne vous identifie pas personnellement. Il permet à son émetteur de reconnaître votre terminal et de collecter un certain nombre d’informations relatives à la navigation effectuée depuis ce terminal.</p>
 
<p>Les données sont collectées à l’occasion des différents contacts que vous avez avec le site web ou l'application mobile. Ces informations sont :</p>
 <ul>
<li>Adresse IP ;</li>
<li>Type de navigateur ;</li>
<li>Langue ;</li>
<li>Horaires d’accès ;</li>
<li>Système d’exploitation.</li>
 </ul>

<p>Ces données sont collectées lorsque vous cliquez sur le bouton "accepter" de la barre se trouvant en bas de la page web.</p>

<h6>Pour plus d’information, Contactez-nous</h6>
<p style="margin-left:40px"> <strong>Adresse</strong> : 43, rue AMANI Belkacem, Paradou, Hydra, Alger<br>
<strong>Mobile</strong> : + 213 (0) 770 112 072 / 73<br/>
<strong>Email</strong> : courrier@macirvie.com</p>

<h6>Relation entre le site https://www.macirvie.com et les réseaux sociaux</h6>
<p>Nous ne sommes pas responsables de l’utilisation des données faites par les réseaux sociaux et notamment lorsque vous utilisez Messenger sur notre site. Vous devez paramétrer et contrôler directement l’accès et la confidentialité de vos données.</p>
<p>Lorsque vous utilisez des réseaux sociaux et des services en relation avec des réseaux sociaux, cela est susceptible d’entraîner une collecte et un échange de certaines données entre les réseaux sociaux et MacirVie.</p>

<h6>Modification de la présente politique</h6>
<p>Le contenu de cette politique est validé en Février 2022, toute modification fera l’objet d’une nouvelle publication sur le site WEB, nous vous invitons à vous connecter sur notre site web à tout moment pour la consulter.</p>
            </div>
        </div>

    </div>

    </div> 
</body>



</html>
