<?php
return [
    'abonnez_vous'=>'Subscribe to the newsletter',
    'inscrivez_vous'=>'Sign up and stay up to date!',
    'Email'=>'Email',
    'Nom'=>'Nom',
    'Prenom'=>'Prénom',
    'recevoir_actu'=>"I would like to receive news from Macir Vie",
    "Je m'abonne"=>'Subscribe'
    ]
?>