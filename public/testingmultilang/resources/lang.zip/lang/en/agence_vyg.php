<?php
return [
    'access_page'=>'Access the space'
]
?>