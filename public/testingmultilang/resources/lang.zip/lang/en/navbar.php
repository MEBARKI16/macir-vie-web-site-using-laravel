<?php
return [
    'newsletter'=>'Newsletter',
    'mymacir'=>'My Macir',
    'first_lang'=>'EN',
    'second_lang'=>'FR',
    'third_lang'=>'العربية',
    'accueil'=>'Home',
    'apropos'=>'About',
    'part'=>'Individuals',
    'part_assu_vyg'=>'Travel insurance',
    'part_assu_acc'=>'Life Accident Guarantee',
    'part_assu_hadj'=>'Hajj and Umrah insurance',
    'part_assu_credit_emp'=>'Credit borrower insurance',
    'part_assu_ayltk'=>'Macir 3AYELTEK Life Insurance',
    'part_assu_tbb'=>'Tabibou Home',
    'pro'=>'Professionals',
    'pro_assu_vyg'=>'Travel insurance',
    'pro_assu_gpe'=>'Group guarantee',
    'pro_assu_credit_emp'=>'Credit borrower insurance',
    'agences_vyg'=>'Travel agencies',
    'declar_sinistre'=>'Declaration of disaster',
    'contact'=>'Contact',
    'actuvie'=>"Actu'Vie"
    ]
?>
