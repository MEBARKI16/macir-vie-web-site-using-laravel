<?php
return [
    "TITLE"=>"Newsletter | Macir Vie",
    'abonnez_vous'=>'Abonnez-vous à la Newsletter',
    'inscrivez_vous'=>'Inscrivez-vous et restez à jour !',
    'Nom'=>'Nom',
    'Prenom'=>'Prénom',
    'Email'=>'Email',
    'recevoir_actu'=>"Je souhaite recevoir l'actualité de Macir Vie.",
    "Je m'abonne"=>"Je m'abonne"
    ]
?>
