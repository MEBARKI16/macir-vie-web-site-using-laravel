<?php
return [
    'TITLE'=>'Recevez notre présentation directement sur votre boîte email',
    'SUB_TITLE'=>'Veuillez remplir les champs suivants:',
    'YOUR_LAST_NAME'=>'Votre Nom',
    'YOUR_FIRST_NAME'=>'Votre Prénom',
    'COMP_NAME'=>'Nom Entreprise',
    'YOUR_EMAIL'=>'Votre Email',
    'FR_VERSION'=>'Version FR',
    'EN_VERSION'=>'Version EN',
    'AR_VERSION'=>'Version AR',
    'SEND'=>'ENVOYER',
    'LAST_NAME'=>'Nom',
    'FIRST_NAME'=>'Prénom',
    'NAME_OF_COMP'=>'Nom de l\'entreprise',
    'EMAIL'=>'Email',
]
?>
