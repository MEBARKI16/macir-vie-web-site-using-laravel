
<?php
return [
    "TITLE"=>"Espace agences de voyages | Macir Vie",
    "ACCESS_PAGE"=>"Accéder à l’espace",
    "ESPACE_AGNC_VYG"=>"Espace agences de voyages",
    "ESPACE_AGNC_VYG_TEXT"=>"Macir Vie met à disposition des agences de voyages conventionnées, un espace dédié pour la gestion desassurances de leurs clients. Cela leur permet de proposer des services et des séjours touristiques uniques,complets, qui répondent aux attentes d'une clientèle de plus en plus exigeante.Pour vous faciliter la conception de ces services et vous permettre d’offrir le meilleur à vos clients, MacirVie a développé une plateforme en ligne, qui vous permet de gérer les contrats d’assurances voyages de tous vos clients.",
    "AVANTAGES"=>"2 bonnes raisons d’utiliser l’espace agences de voyages",
    "AVANTAGES_TITRE1"=>" UNE GESTION 100 % EN LIGNE",
    "AVANTAGES_TEXT1"=>"L’espace vous permet de gérer les dossiers et les contrats d’assurance voyage de vos clients en quelques clics depuis votre bureau",
    "AVANTAGES_TITRE2"=>"REMISES EXCEPTIONNELLES",
    "AVANTAGES_TEXT2"=>"Rejoignez l’espace consacré aux agences de voyages et bénéficiez de remises exceptionnelles sur les tarifs des assurances voyages. ",
]
?>
