<?php
return [
    'DISCOVER_US'=>'Découvrez-nous',
    'LANG'=>'Langue',
    'newsletter'=>'Newsletter',
    'mymacir'=>'My Macir',
    'first_lang'=>'EN',
    'second_lang'=>'FR',
    'third_lang'=>'العربية',
    'accueil'=>'Accueil',
    'apropos'=>'À propos',
    'part'=>'Particuliers',
    'part_assu_vyg'=>'MyM Voyage',
    'part_assu_acc'=>'MyM Protection Accidents',
    'part_assu_hadj'=>'MyM Hadj & Omra',
    'part_assu_credit_emp'=>'MyM Crédit',
    'part_assu_ayltk'=>'Assurance Vie Macir 3AYELTEK',
    'part_assu_tbb'=>'Tabibou Home',
    'pro'=>'Professionnels',
    'pro_assu_vyg'=>'MyM Voyage',
    'pro_assu_gpe'=>'MyM Groupe',
    'pro_assu_credit_emp'=>'MyM Crédit',
    'agences_vyg'=>'Agences de voyages',
    'declar_sinistre'=>'Déclaration de sinistre',
    'contact'=>'Contact',
    'actuvie'=>"Actu'Vie"
    ]
?>
