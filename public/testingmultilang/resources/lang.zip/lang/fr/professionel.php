<?php
return [
    "TITLE"=>"Professionnels | Macir Vie",
    'PRO'=>'Espace professionnels',
    'PRO_CONTENT'=>'Macir Vie a développé des produits et des services sur-mesure, afin de répondre au mieux aux besoins et attentes des entreprises et des professionnels en matière d’assurance de personnes.',
    ]
?>
