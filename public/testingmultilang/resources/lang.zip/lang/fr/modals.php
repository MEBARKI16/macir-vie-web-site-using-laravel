<?php
return [
    'PARAGRAPH1'=>'Nous vous proposons des produits adaptés à vos besoins.',
    'PARAGRAPH2'=>'Sélectionnez celui qui vous convient!',
    'PARAGRAPHE3'=>'Comparez et évaluez les garanties comprises dans vos contrats d\'assurance en fonction de vos besoins, budgets et attentes.',
]
?>
