<?php
return [
    "TITLE"=>"Particuliers | Macir Vie",
    'PART'=>'Espace particulier',
    'PART_CONTENT'=>' Macir Vie a développé des produits et des services sur-mesure, afin de répondre au mieux à vos besoins et ceux de vos proches en matière d\'assurance de personnes ',
    ]
?>
