<?php
return [
    'DISCOVER_US'=>'اكتشفونا',
    'LANG'=>'لغة',
    'newsletter'=>'نشرتنا الإخبارية',
    'mymacir'=>'My Macir',
    'first_lang'=>'EN',
    'second_lang'=>'FR',
    'third_lang'=>'العربية',
    'accueil'=>'الصفحة الرئيسية',
    'apropos'=>'بخصوص',
    'part'=>'الخواص',
    'part_assu_vyg'=>'MyM Voyage',
    'part_assu_acc'=>'MyM Protection Accidents',
    'part_assu_hadj'=>'MyM Hadj & Omra',
    'part_assu_credit_emp'=>'MyM Crédit',
    'part_assu_ayltk'=>'Assurance Vie Macir 3AYELTEK',
    'part_assu_tbb'=>'Tabibou Home',
    'pro'=>'مهنيين',
    'pro_assu_vyg'=>'MyM Voyage',
    'pro_assu_gpe'=>'MyM Groupe',
    'pro_assu_credit_emp'=>'MyM Crédit',
    'agences_vyg'=>'وكالات السفر',
    'declar_sinistre'=>'Déclaration de sinistre',
    'contact'=>'اتصل بنا',
    'actuvie'=>"Actu'Vie"
    ]
?>
