<?php
return [
    "TITLE"=>"Newsletter | Macir Vie",
    'abonnez_vous'=>'اشتركوا في نشرتنا الإخبارية',
    'inscrivez_vous'=>'سجلوا أنفسكم و ابقوا على اطلاع !',
    'Nom'=>'اللقب',
    'Prenom'=>'الاسم',
    'Email'=>'البريد الالكتروني',
    'recevoir_actu'=>"أود أن أتحصل على مستجدات مصير للحياة     ",
    "Je m'abonne"=>"أنا أشترك"
    ]
?>
