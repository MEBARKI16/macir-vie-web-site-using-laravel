<?php
return [
    "TITLE"=>"تأمين ضد حوادث الحياة | مصير للحياة",
    "PROTECTION_ACCIDENT"=>"Protection Accidents MyM",
    "PROTECTION_ACCIDENT_TEXT"=>"تسمح لكم MyM Protection Accidents ولأقربائكم بالتعويض في حالة الوفاة أو الإصابة الجسدية التي تحدث خلال حياتكم الخاصة أو المهنية.",
    "POURQUOI_SOUSCRIRE"=>"لماذا الاشتراك؟",
    "POURQUOI_SOUSCRIRE_TEXT1"=>"التغطية الدولية: مع تأمين MyM Protection Accidents مصير للحياة ،يتم تغطيتكم في أي مكان في العالم ، لمدة تصل إلى 60 يومًا. ",
    "POURQUOI_SOUSCRIRE_TEXT2"=>"مستوى كبير من التعويض:  يقدم لكم MyM Protection Accidents لمصير للحياة تعويضات تصل إلى 000 000 10 دج  في حالة الوفاة و 000 000 1 دج  عن جميع نفقاتكم الطبية والصيدلانية والاستشفائية",
    "AVANTAGES"=>"مزايا تأمين ضمان الحوادث على الحياة الخاصة بمصير للحياة ",
    "AVANTAGES_TITRE1"=>"احم عائلتك أيضًا",
    "AVANTAGES_TEXT1"=>"يغطي مصير للحياة أيضًا زوجتك و / أو أطفالك ضد عواقب حادث جسدي.",
    "AVANTAGES_TITRE2"=>"التغطية متاحة في جميع أنحاء العالم",
    "AVANTAGES_TEXT2"=>"مع MyM Protection Accidents ، تمتع بتغطية عالمية للإقامة لمدة تصل إلى 60 يومًا",
    "AVANTAGES_TITRE3"=>"الدعم في حالة وقوع حادث",
    "AVANTAGES_TEXT3"=>"استفد من تغطية نفقاتك الطبية والصيدلانية والمستشفى في حالة حدوث إصابة جسدية.",
]
?>
