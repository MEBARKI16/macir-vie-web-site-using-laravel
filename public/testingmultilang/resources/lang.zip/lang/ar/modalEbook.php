<?php
return [
    'TITLE'=>'تلقى العرض التقديمي لشركتنا مباشرة على بريدك الإلكتروني',
    'SUB_TITLE'=>'يرجى ادخال بياناتك التالية::',
    'YOUR_LAST_NAME'=>'اللقب',
    'YOUR_FIRST_NAME'=>'الاسم',
    'COMP_NAME'=>'اسم شركتك',
    'YOUR_EMAIL'=>'البريد الالكتروني',
    'FR_VERSION'=>'نسخة فرنسية',
    'EN_VERSION'=>'نسخة إنجليزية',
    'AR_VERSION'=>'نسخة عربية',
    'SEND'=>'ارسال',
    'LAST_NAME'=>'اللقب',
    'FIRST_NAME'=>'الاسم',
    'NAME_OF_COMP'=>'الشركة',
    'EMAIL'=>'البريد الالكتروني',
    'SEND_SUCCESS'=>'تم إرسال العرض بنجاح',
    'SEND_ERROR_ALERT'=>'حدث خطأ أثناء إرسال العرض',
    'SEND_ERROR'=>'عفوًا ، لقد حدث خطأ',

]
?>
